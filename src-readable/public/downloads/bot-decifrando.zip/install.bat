@echo off
REM Script de instalação para Windows - Bot Decifrando

echo.
echo ==========================================
echo 🚀 Bot Decifrando - Setup para Windows
echo ==========================================
echo.

REM Verifica se Python está instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python não encontrado!
    echo 💾 Baixe em: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo ✅ Python encontrado:
python --version
echo.

REM Cria ambiente virtual
echo 📦 Criando ambiente virtual...
python -m venv venv

REM Ativa ambiente virtual
echo ✅ Ativando ambiente virtual...
call venv\Scripts\activate.bat

REM Instala dependências
echo.
echo 📥 Instalando dependências...
pip install -r requirements.txt

REM Cria arquivo .env
if not exist .env (
    echo.
    echo 📝 Criando arquivo .env...
    copy .env.example .env
    echo ⚠️  Edite o arquivo .env se necessário
) else (
    echo ✅ Arquivo .env já existe
)

echo.
echo ==========================================
echo ✨ Setup concluído com sucesso!
echo ==========================================
echo.
echo 🚀 Para iniciar o bot, execute:
echo    python app.py
echo.
echo 📖 Leia o COMECE_AQUI.md para mais informações!
echo.
pause
